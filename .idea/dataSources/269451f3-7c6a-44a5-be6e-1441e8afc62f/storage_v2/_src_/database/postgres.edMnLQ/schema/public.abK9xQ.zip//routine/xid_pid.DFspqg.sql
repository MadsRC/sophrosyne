create function xid_pid(_xid public.xid) returns integer
    language plpgsql
as
$$
DECLARE
    _id int[];
BEGIN
    _id := public.xid_decode(_xid);
    return (_id[8] << 8) + (_id[9]);
END;
$$;

alter function xid_pid(public.xid) owner to postgres;

