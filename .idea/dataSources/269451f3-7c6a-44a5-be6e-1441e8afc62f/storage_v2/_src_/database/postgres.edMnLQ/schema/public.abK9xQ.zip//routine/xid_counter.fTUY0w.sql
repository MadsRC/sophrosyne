create function xid_counter(_xid public.xid) returns integer
    language plpgsql
as
$$
DECLARE
    _id int[];
BEGIN
    _id := public.xid_decode(_xid);
    return (_id[10] << 16) + (_id[11] << 8) + (_id[12]);
END;
$$;

alter function xid_counter(public.xid) owner to postgres;

