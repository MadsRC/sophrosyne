create function _xid_machine_id() returns integer
    immutable
    language plpgsql
as
$$
DECLARE
BEGIN
    RETURN (SELECT system_identifier & 16777215 FROM pg_control_system());
END
$$;

alter function _xid_machine_id() owner to postgres;

