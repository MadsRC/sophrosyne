create function xid_machine(_xid public.xid) returns integer[]
    language plpgsql
as
$$
DECLARE
    _id int[];
BEGIN
    _id := public.xid_decode(_xid);
    return ARRAY [_id[5], _id[6], _id[7]];
END;
$$;

alter function xid_machine(public.xid) owner to postgres;

