create function xid_time(_xid public.xid) returns timestamp with time zone
    language plpgsql
as
$$
DECLARE
    _id int[];
BEGIN
    _id := public.xid_decode(_xid);
    return to_timestamp((_id[1] << 24)::BIGINT + (_id[2] << 16) + (_id[3] << 8) + (_id[4]));
END;
$$;

alter function xid_time(public.xid) owner to postgres;

