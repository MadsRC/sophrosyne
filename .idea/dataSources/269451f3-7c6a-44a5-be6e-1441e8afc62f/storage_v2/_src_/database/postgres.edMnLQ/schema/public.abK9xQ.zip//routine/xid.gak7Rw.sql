create function xid(_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP) returns public.xid
    language plpgsql
as
$$
DECLARE
    _t INT;
    _m INT;
    _p INT;
    _c INT;
BEGIN
    _t := floor(EXTRACT(epoch FROM _at));
    _m := _xid_machine_id();
    _p := pg_backend_pid();
    _c := nextval('xid_serial')::INT;

    return public.xid_encode(ARRAY [
        (_t >> 24) & 255, (_t >> 16) & 255, (_t >> 8) & 255 , _t & 255,
        (_m >> 16) & 255, (_m >> 8) & 255 , _m & 255,
        (_p >> 8) & 255, _p & 255,
        (_c >> 16) & 255, (_c >> 8) & 255 , _c & 255
        ]);
END;
$$;

alter function xid(timestamp with time zone) owner to postgres;

